<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Thanks from Utopians</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- LINEARICONS -->
		<link rel="stylesheet" href="fonts/linearicons/style.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
                <link rel="icon" href="logo.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="logo.ico" type="image/x-icon" />
	</head>

	<body>

		<div class="wrapper" dir="rtl">
			<div class="inner">
				
				<form action="" method="POST" style="text-align: center;">
					<p style="text-align: center;"><img src="logo.png" height="150"></p>
<br>
					<h4>شكراً لاهتمامك بالتطوع معنا </h3><br>
					<h4>لقد تم تسجيل طلبك و سيتم التواصل معك قريباً    </h3><br>
                                         <p>يرجى إضافة الحساب التالي ليتم التواصل معك من قبل قسم الموارد البشرية <a href="https://www.facebook.com/HR.ASTPE">رابط الحساب</a></p>
					
				</form>
				
			</div>
			
		</div>
		
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/main.js"></script>
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>